package main

import server "mamfyou/internal/handler"

func main() {	
	server.Start()
}
